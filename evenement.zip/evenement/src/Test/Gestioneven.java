/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Connection.MyConnection;
import Entité.Evenement;
import Service.EvenementService;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Date;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lotfi
 */
public class Gestioneven {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyConnection mc = MyConnection.getInstance();
/*            Evenement e1 = new Evenement( 1,"hhhhhhh","treessss dangeraux","13/05/2000","12-01-1905","siliana","les medecins","club sante" );
            Evenement e2 = new Evenement( 2,"ccccccc"," dangeraux","13/05/1995","22-01-2016","nabeul","les medecins et patient","club");
            Evenement e3 = new Evenement(3,"kkkkkk","incroyable","24-08-1985","19-07-2007","tunisia","les maladies du sucre","clinique sokra");
       
EvenementService es = new EvenementService();
            es.ajouterEvenement(e1);
           es.ajouterEvenement(e2);
           es.ajouterEvenement(e3);
          
           es.supprimerEvenement(74);
           es.supprimerEvenement(71);
           e2.setIdeven(22);
           e2.setDescriptioneven("mouch normal");
           e2.setDatedebut("09-10-1971");
           e2.setDatefin("29-01-1991");
           e2.setLieueven("italia");
           e2.setInvitees("docteur bouzayen");
           e2.setRespensable("hopital sahloul");
           es.modifierEvenement(e2);
             es.afficherEvenement();
 */       
        
        
        
        
        
        
        
        
    }
    
}
